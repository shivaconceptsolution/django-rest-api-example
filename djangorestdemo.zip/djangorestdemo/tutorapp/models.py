from django.db import models
from django.db import models

class TutorReg(models.Model):
    password = models.CharField(max_length=10)
    mobileno = models.CharField(max_length=10)
    fname = models.CharField(max_length=20)
    def __str__(self):
        return "Password is "+self.password + " Mobile no is "+self.mobileno + " fname is "+self.fname

