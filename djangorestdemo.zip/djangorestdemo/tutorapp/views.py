from .models import TutorReg
from rest_framework import viewsets
from rest_framework import permissions
from tutorapp.serializers import TutorSerializer

class TutorViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = TutorReg.objects.all()
    serializer_class = TutorSerializer
   
