from .models import TutorReg
from rest_framework import serializers
class TutorSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = TutorReg
        fields = ['password', 'mobileno','fname']